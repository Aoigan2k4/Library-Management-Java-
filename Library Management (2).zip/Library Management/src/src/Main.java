package src;
public class Main {
    public static void main(String[] args) {
        Library lb = new Library();
        lb.Start();
    }
}